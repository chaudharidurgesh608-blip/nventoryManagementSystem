-- ============================================================================
-- INVENTORY MANAGEMENT SYSTEM (IMS) - DATABASE SCRIPT
-- BCA Major Project Database Architecture & Sample Data
-- Database Engine: Microsoft SQL Server 2022
-- ============================================================================

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'InventoryManagementDb')
BEGIN
    CREATE DATABASE [InventoryManagementDb];
END
GO

USE [InventoryManagementDb];
GO

-- 1. Create Categories Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Categories')
BEGIN
    CREATE TABLE [dbo].[Categories] (
        [CategoryId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [CategoryName] NVARCHAR(100) NOT NULL,
        [Description] NVARCHAR(500) NULL,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END
GO

-- 2. Create Suppliers Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Suppliers')
BEGIN
    CREATE TABLE [dbo].[Suppliers] (
        [SupplierId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [SupplierName] NVARCHAR(150) NOT NULL,
        [Phone] NVARCHAR(20) NULL,
        [Email] NVARCHAR(100) NULL,
        [Address] NVARCHAR(250) NULL,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END
GO

-- 3. Create AspNetUsers Table (ASP.NET Core Identity)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AspNetUsers')
BEGIN
    CREATE TABLE [dbo].[AspNetUsers] (
        [Id] NVARCHAR(450) NOT NULL PRIMARY KEY,
        [FullName] NVARCHAR(100) NOT NULL,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        [UserName] NVARCHAR(256) NULL,
        [NormalizedUserName] NVARCHAR(256) NULL,
        [Email] NVARCHAR(256) NULL,
        [NormalizedEmail] NVARCHAR(256) NULL,
        [EmailConfirmed] BIT NOT NULL DEFAULT 1,
        [PasswordHash] NVARCHAR(MAX) NULL,
        [SecurityStamp] NVARCHAR(MAX) NULL,
        [ConcurrencyStamp] NVARCHAR(MAX) NULL,
        [PhoneNumber] NVARCHAR(MAX) NULL,
        [PhoneNumberConfirmed] BIT NOT NULL DEFAULT 0,
        [TwoFactorEnabled] BIT NOT NULL DEFAULT 0,
        [LockoutEnd] DATETIMEOFFSET(7) NULL,
        [LockoutEnabled] BIT NOT NULL DEFAULT 1,
        [AccessFailedCount] INT NOT NULL DEFAULT 0
    );
END
GO

-- 4. Create Products Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Products')
BEGIN
    CREATE TABLE [dbo].[Products] (
        [ProductId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [ProductName] NVARCHAR(150) NOT NULL,
        [Description] NVARCHAR(500) NULL,
        [SKU] NVARCHAR(50) NOT NULL UNIQUE,
        [CategoryId] INT NOT NULL,
        [SupplierId] INT NOT NULL,
        [Price] DECIMAL(18,2) NOT NULL,
        [Quantity] INT NOT NULL DEFAULT 0,
        [MinimumStockLevel] INT NOT NULL DEFAULT 5,
        [CreatedAt] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        [UpdatedAt] DATETIME2 NULL,
        CONSTRAINT [FK_Products_Categories] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[Categories]([CategoryId]),
        CONSTRAINT [FK_Products_Suppliers] FOREIGN KEY ([SupplierId]) REFERENCES [dbo].[Suppliers]([SupplierId])
    );
END
GO

-- 5. Create StockTransactions Table (Audit Trail)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'StockTransactions')
BEGIN
    CREATE TABLE [dbo].[StockTransactions] (
        [TransactionId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [ProductId] INT NOT NULL,
        [TransactionType] NVARCHAR(10) NOT NULL, -- 'IN' or 'OUT'
        [Quantity] INT NOT NULL,
        [Remarks] NVARCHAR(250) NULL,
        [TransactionDate] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        [UserId] NVARCHAR(450) NULL,
        CONSTRAINT [FK_StockTransactions_Products] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Products]([ProductId]) ON DELETE CASCADE,
        CONSTRAINT [FK_StockTransactions_Users] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AspNetUsers]([Id])
    );
END
GO

-- ============================================================================
-- SEED SAMPLE DATA
-- ============================================================================

-- Insert Categories if empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories])
BEGIN
    INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES
    ('Electronics', 'Computer hardware, peripherals, and electronic accessories'),
    ('Furniture', 'Office chairs, standing desks, and storage cabinets'),
    ('Office Supplies', 'A4 papers, toner cartridges, pens, and desk organizers');
END
GO

-- Insert Suppliers if empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[Suppliers])
BEGIN
    INSERT INTO [dbo].[Suppliers] ([SupplierName], [Phone], [Email], [Address]) VALUES
    ('Tech Distributors Ltd', '+91 9876543210', 'tech@distributors.com', 'Plot 45, MIDC Industrial Area, Andheri East, Mumbai'),
    ('Modern Furnishings Inc', '+91 9811223344', 'contact@modernfurnish.com', 'Sector 18, Electronic City, Noida, Delhi NCR'),
    ('Prime Stationery Hub', '+91 9822334455', 'sales@primestationery.in', 'Brigade Road, Shivaji Nagar, Bengaluru, Karnataka');
END
GO

-- Insert Products if empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[Products])
BEGIN
    DECLARE @catElectronics INT = (SELECT TOP 1 CategoryId FROM Categories WHERE CategoryName = 'Electronics');
    DECLARE @catFurniture INT = (SELECT TOP 1 CategoryId FROM Categories WHERE CategoryName = 'Furniture');
    DECLARE @catOffice INT = (SELECT TOP 1 CategoryId FROM Categories WHERE CategoryName = 'Office Supplies');

    DECLARE @supTech INT = (SELECT TOP 1 SupplierId FROM Suppliers WHERE SupplierName = 'Tech Distributors Ltd');
    DECLARE @supFurniture INT = (SELECT TOP 1 SupplierId FROM Suppliers WHERE SupplierName = 'Modern Furnishings Inc');
    DECLARE @supStationery INT = (SELECT TOP 1 SupplierId FROM Suppliers WHERE SupplierName = 'Prime Stationery Hub');

    INSERT INTO [dbo].[Products] ([ProductName], [Description], [SKU], [CategoryId], [SupplierId], [Price], [Quantity], [MinimumStockLevel]) VALUES
    ('Dell Latitude 5420 Laptop', 'Intel Core i5 11th Gen, 16GB RAM, 512GB SSD', 'LAP-DELL-01', @catElectronics, @supTech, 65000.00, 25, 5),
    ('Logitech MX Master 3S Mouse', 'Wireless ergonomic mouse with quiet clicks', 'MOU-LOGI-02', @catElectronics, @supTech, 8999.00, 4, 5),
    ('Ergonomic High-Back Mesh Chair', 'Adjustable lumbar support and 3D armrests', 'CHR-ERGO-03', @catFurniture, @supFurniture, 12500.00, 15, 3),
    ('Century Star A4 Copier Paper (75 GSM)', 'Ream of 500 sheets multipurpose copy paper', 'PAP-A4-04', @catOffice, @supStationery, 350.00, 0, 10),
    ('Redragon K552 Mechanical Keyboard', 'RGB backlit mechanical gaming and typing keyboard', 'KBD-MECH-05', @catElectronics, @supTech, 4500.00, 18, 4);
END
GO

-- Insert Sample Transactions if empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[StockTransactions])
BEGIN
    DECLARE @prodDell INT = (SELECT TOP 1 ProductId FROM Products WHERE SKU = 'LAP-DELL-01');
    DECLARE @prodLogi INT = (SELECT TOP 1 ProductId FROM Products WHERE SKU = 'MOU-LOGI-02');
    DECLARE @prodChair INT = (SELECT TOP 1 ProductId FROM Products WHERE SKU = 'CHR-ERGO-03');

    INSERT INTO [dbo].[StockTransactions] ([ProductId], [TransactionType], [Quantity], [Remarks], [TransactionDate]) VALUES
    (@prodDell, 'IN', 25, 'Initial purchase order stock received', DATEADD(DAY, -5, SYSUTCDATETIME())),
    (@prodLogi, 'IN', 10, 'Initial procurement batch', DATEADD(DAY, -4, SYSUTCDATETIME())),
    (@prodLogi, 'OUT', 6, 'Dispatched to Engineering Team', DATEADD(DAY, -1, SYSUTCDATETIME())),
    (@prodChair, 'IN', 15, 'Office renovation batch delivery', DATEADD(DAY, -2, SYSUTCDATETIME()));
END
GO

PRINT '=======================================================';
PRINT 'InventoryManagementDb Database setup completed successfully!';
PRINT '=======================================================';
